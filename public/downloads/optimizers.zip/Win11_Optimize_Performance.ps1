#Requires -RunAsAdministrator
<#
.SYNOPSIS
    Windows 11 Performance & Speed Optimizer  (Verbose Edition)
.DESCRIPTION
    Applies performance tweaks with full verbose output — every registry path,
    value, service state change, file count deleted, and timestamped action.
.NOTES
    Run as Administrator. Creates a restore point before making changes.
#>

Set-StrictMode -Version Latest
$ErrorActionPreference = "Continue"
$script:StepNum   = 0
$script:OKCount   = 0
$script:SkipCount = 0
$script:ErrCount  = 0
$script:StartTime = Get-Date

# ─────────────────────────────────────────────
#  Output Helpers
# ─────────────────────────────────────────────
function Write-Banner {
    Clear-Host
    Write-Host ""
    Write-Host "  +====================================================+" -ForegroundColor Cyan
    Write-Host "  |    Windows 11 Performance & Speed Optimizer        |" -ForegroundColor Cyan
    Write-Host "  |    Verbose Edition  |  Run as Administrator        |" -ForegroundColor Cyan
    Write-Host "  +====================================================+" -ForegroundColor Cyan
    Write-Host ""
}

function Write-Header {
    param([string]$Title)
    $script:StepNum++
    $ts = (Get-Date).ToString("HH:mm:ss")
    Write-Host ""
    Write-Host "  +----------------------------------------------------" -ForegroundColor DarkCyan
    Write-Host "  |  [$ts]  STEP $($script:StepNum): $Title" -ForegroundColor Cyan
    Write-Host "  +----------------------------------------------------" -ForegroundColor DarkCyan
}

function Write-Action {
    param([string]$Text)
    $ts = (Get-Date).ToString("HH:mm:ss.fff")
    Write-Host "  [$ts] >> $Text" -ForegroundColor Yellow
}

function Write-Detail {
    param([string]$Text)
    Write-Host "             $Text" -ForegroundColor DarkYellow
}

function Write-RegSet {
    param([string]$Path, [string]$Name, $Value)
    Write-Host "             REG  $Path" -ForegroundColor DarkGray
    Write-Host "                  |_ $Name = $Value" -ForegroundColor DarkGray
}

function Write-OK {
    param([string]$Text)
    $ts = (Get-Date).ToString("HH:mm:ss.fff")
    Write-Host "  [$ts] OK $Text" -ForegroundColor Green
    $script:OKCount++
}

function Write-Skip {
    param([string]$Text)
    $ts = (Get-Date).ToString("HH:mm:ss.fff")
    Write-Host "  [$ts] -- $Text" -ForegroundColor DarkGray
    $script:SkipCount++
}

function Write-Err {
    param([string]$Text)
    $ts = (Get-Date).ToString("HH:mm:ss.fff")
    Write-Host "  [$ts] !! $Text" -ForegroundColor Red
    $script:ErrCount++
}

function Write-Summary {
    $elapsed = ((Get-Date) - $script:StartTime).TotalSeconds
    Write-Host ""
    Write-Host "  +====================================================+" -ForegroundColor Cyan
    Write-Host "  |                  RUN SUMMARY                       |" -ForegroundColor Cyan
    Write-Host "  +====================================================+" -ForegroundColor Cyan
    Write-Host ("  |  OK Successful  : {0,-34}|" -f $script:OKCount)    -ForegroundColor Green
    Write-Host ("  |  -- Skipped     : {0,-34}|" -f $script:SkipCount)  -ForegroundColor DarkGray
    $errColor = if ($script:ErrCount -gt 0) { "Red" } else { "DarkGray" }
    Write-Host ("  |  !! Errors      : {0,-34}|" -f $script:ErrCount)   -ForegroundColor $errColor
    Write-Host ("  |  Elapsed        : {0,-34}|" -f ("{0:N1}s" -f $elapsed)) -ForegroundColor White
    Write-Host "  +----------------------------------------------------+" -ForegroundColor Cyan
    Write-Host "  |  ** RESTART YOUR COMPUTER to apply all changes **  |" -ForegroundColor Magenta
    Write-Host "  +====================================================+" -ForegroundColor Cyan
    Write-Host ""
}

# ─────────────────────────────────────────────
#  Registry Helper (verbose)
# ─────────────────────────────────────────────
function Set-RegVal {
    param(
        [string]$Path,
        [string]$Name,
        $Value,
        [string]$Type = "DWord"
    )
    Write-RegSet -Path $Path -Name $Name -Value $Value
    try {
        if (-not (Test-Path $Path)) {
            Write-Detail "Path not found — creating: $Path"
            New-Item -Path $Path -Force | Out-Null
        }
        # Read old value for diff
        try {
            $old = (Get-ItemProperty -Path $Path -Name $Name -ErrorAction Stop).$Name
            Write-Detail "Old value: $old  ->  New value: $Value"
        } catch {
            Write-Detail "Key did not exist — creating fresh."
        }
        Set-ItemProperty -Path $Path -Name $Name -Value $Value -Type $Type -Force -ErrorAction Stop
    } catch {
        Write-Err "Failed to set $Name at $Path — $_"
    }
}

# =============================================================
#  START
# =============================================================
Write-Banner

# ─────────────────────────────────────────────
#  0. System Restore Point
# ─────────────────────────────────────────────
Write-Header "System Restore Point"
Write-Action "Enabling System Restore on C:\..."
try {
    Enable-ComputerRestore -Drive "C:\" -ErrorAction SilentlyContinue
    Write-Action "Creating checkpoint: 'Before Win11 Performance Optimization'..."
    Checkpoint-Computer -Description "Before Win11 Performance Optimization" `
                        -RestorePointType "MODIFY_SETTINGS" -ErrorAction Stop
    Write-OK "Restore point created successfully."
} catch {
    Write-Skip "Restore point skipped (Windows allows one per day, or VSS unavailable): $_"
}

# ─────────────────────────────────────────────
#  1. Power Plan
# ─────────────────────────────────────────────
Write-Header "Power Plan -> High Performance"
Write-Action "Querying all installed power plans..."
$allPlans = powercfg -list
$allPlans | ForEach-Object { Write-Detail $_ }

$hp = $allPlans | Select-String "High performance"
if ($hp) {
    $guid = ($hp -split '\s+')[3]
    Write-Action "Matched High Performance GUID: $guid"
    Write-Action "Executing: powercfg -setactive $guid"
    powercfg -setactive $guid
    Write-OK "High Performance power plan is now ACTIVE."
} else {
    Write-Action "High Performance plan not found — duplicating Minimum Power Savings..."
    $out = powercfg -duplicatescheme SCHEME_MIN
    Write-Detail $out
    $newGuid = ($out -split '\s+')[-1]
    powercfg -changename $newGuid "High Performance (Custom)"
    powercfg -setactive $newGuid
    Write-OK "Created and activated custom High Performance plan: $newGuid"
}

Write-Action "Confirming active scheme:"
powercfg -getactivescheme | ForEach-Object { Write-Detail $_ }

# ─────────────────────────────────────────────
#  2. Visual Effects
# ─────────────────────────────────────────────
Write-Header "Visual Effects -> Best Performance"

Write-Action "Setting VisualFXSetting = 2 (Adjust for best performance)..."
Set-RegVal "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\VisualEffects" "VisualFXSetting" 2

Write-Action "Disabling dragging full window contents (DragFullWindows = 0)..."
Set-RegVal "HKCU:\Control Panel\Desktop" "DragFullWindows" "0" -Type String

Write-Action "Setting menu show delay to 0 ms (MenuShowDelay = 0)..."
Set-RegVal "HKCU:\Control Panel\Desktop" "MenuShowDelay" "0" -Type String

Write-Action "Applying performance-optimised UserPreferencesMask (binary)..."
Set-RegVal "HKCU:\Control Panel\Desktop" "UserPreferencesMask" `
    ([byte[]](0x90,0x12,0x01,0x80,0x10,0x00,0x00,0x00)) -Type Binary

Write-Action "Disabling window minimize/maximize animations (MinAnimate = 0)..."
Set-RegVal "HKCU:\Control Panel\Desktop\WindowMetrics" "MinAnimate" "0" -Type String

Write-OK "All visual effect registry values written."

# ─────────────────────────────────────────────
#  3. Transparency & Animations
# ─────────────────────────────────────────────
Write-Header "Transparency & Taskbar Animations"

Write-Action "Disabling Fluent/Acrylic transparency (EnableTransparency = 0)..."
Set-RegVal "HKCU:\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize" `
           "EnableTransparency" 0

Write-Action "Disabling taskbar button animations (TaskbarAnimations = 0)..."
Set-RegVal "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" `
           "TaskbarAnimations" 0

Write-OK "Transparency and animations disabled."

# ─────────────────────────────────────────────
#  4. Startup Delay
# ─────────────────────────────────────────────
Write-Header "Explorer Startup Delay"
Write-Action "Setting StartupDelayInMSec = 0 (default Windows value is 10000 ms)..."
Set-RegVal "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Serialize" `
           "StartupDelayInMSec" 0
Write-OK "Explorer startup delay eliminated (saved ~10 seconds on login)."

# ─────────────────────────────────────────────
#  5. Prefetch
# ─────────────────────────────────────────────
Write-Header "Prefetch / ReadyBoot"
$pfPath = "HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management\PrefetchParameters"

Write-Action "Reading current Prefetch values..."
try {
    $cur = Get-ItemProperty -Path $pfPath -ErrorAction Stop
    Write-Detail "Current EnablePrefetcher = $($cur.EnablePrefetcher)  (target: 3)"
    Write-Detail "Current EnableSuperfetch = $($cur.EnableSuperfetch)  (target: 3)"
} catch { Write-Detail "Could not read current values — will write anyway." }

Write-Action "Setting EnablePrefetcher = 3 (boot + app prefetch)..."
Set-RegVal $pfPath "EnablePrefetcher" 3

Write-Action "Setting EnableSuperfetch = 3..."
Set-RegVal $pfPath "EnableSuperfetch" 3

Write-OK "Prefetch parameters set."

# ─────────────────────────────────────────────
#  6. Services
# ─────────────────────────────────────────────
Write-Header "Disable Unnecessary Services"

$services = @(
    @{ Name = "DiagTrack";      Display = "Connected User Experiences & Telemetry" },
    @{ Name = "WSearch";        Display = "Windows Search" },
    @{ Name = "SysMain";        Display = "SysMain (Superfetch)" },
    @{ Name = "MapsBroker";     Display = "Downloaded Maps Manager" },
    @{ Name = "XblAuthManager"; Display = "Xbox Live Auth Manager" },
    @{ Name = "XblGameSave";    Display = "Xbox Live Game Save" },
    @{ Name = "XboxNetApiSvc";  Display = "Xbox Live Networking Service" },
    @{ Name = "RetailDemo";     Display = "Retail Demo Service" }
)

foreach ($svc in $services) {
    Write-Action "Service: $($svc.Display)  [$($svc.Name)]"
    $s = Get-Service -Name $svc.Name -ErrorAction SilentlyContinue
    if ($s) {
        Write-Detail "  Status    : $($s.Status)"
        Write-Detail "  StartType : $($s.StartType)"
        Write-Detail "  DisplayName: $($s.DisplayName)"
        try {
            if ($s.Status -ne "Stopped") {
                Write-Detail "  -> Stopping service..."
                Stop-Service -Name $svc.Name -Force -ErrorAction SilentlyContinue
                Start-Sleep -Milliseconds 600
                $s.Refresh()
                Write-Detail "  -> Status after stop: $($s.Status)"
            } else {
                Write-Detail "  -> Already stopped."
            }
            Set-Service -Name $svc.Name -StartupType Disabled -ErrorAction Stop
            Write-Detail "  -> StartupType set to: Disabled"
            Write-OK "$($svc.Display) — DISABLED."
        } catch {
            Write-Err "Could not fully disable $($svc.Display): $_"
        }
    } else {
        Write-Skip "$($svc.Display) [$($svc.Name)] — not installed on this system."
    }
}

# ─────────────────────────────────────────────
#  7. Background Apps
# ─────────────────────────────────────────────
Write-Header "Background App Access"
Write-Action "Writing GlobalUserDisabled = 1 to BackgroundAccessApplications..."
Write-Detail "This blocks all Store apps from running in the background."
Set-RegVal "HKCU:\Software\Microsoft\Windows\CurrentVersion\BackgroundAccessApplications" `
           "GlobalUserDisabled" 1
Write-OK "Background apps restricted for all applications."

# ─────────────────────────────────────────────
#  8. Game Mode & HAGS
# ─────────────────────────────────────────────
Write-Header "Game Mode & Hardware-Accelerated GPU Scheduling"

Write-Action "Enabling AllowAutoGameMode = 1..."
Set-RegVal "HKCU:\Software\Microsoft\GameBar" "AllowAutoGameMode" 1

Write-Action "Enabling AutoGameModeEnabled = 1..."
Set-RegVal "HKCU:\Software\Microsoft\GameBar" "AutoGameModeEnabled" 1

Write-OK "Windows Game Mode enabled."

Write-Action "Enabling Hardware-Accelerated GPU Scheduling — HwSchMode = 2..."
Write-Detail "Requires: DirectX 12 GPU + WDDM 2.7+ driver. Takes effect after reboot."
Set-RegVal "HKLM:\SYSTEM\CurrentControlSet\Control\GraphicsDrivers" "HwSchMode" 2
Write-OK "HAGS enabled — REBOOT REQUIRED to activate."

# ─────────────────────────────────────────────
#  9. Memory / Paging
# ─────────────────────────────────────────────
Write-Header "Memory & Page File Settings"
$memPath = "HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management"

Write-Action "Reading current memory management settings..."
try {
    $m = Get-ItemProperty -Path $memPath -ErrorAction Stop
    Write-Detail "ClearPageFileAtShutdown = $($m.ClearPageFileAtShutdown)  (target: 0)"
    Write-Detail "LargeSystemCache        = $($m.LargeSystemCache)  (target: 0)"
} catch { Write-Detail "Could not read current values." }

Write-Action "ClearPageFileAtShutdown = 0 (keep pagefile; speeds up shutdown)..."
Set-RegVal $memPath "ClearPageFileAtShutdown" 0

Write-Action "LargeSystemCache = 0 (optimised for foreground desktop apps)..."
Set-RegVal $memPath "LargeSystemCache" 0

Write-OK "Memory and page file settings applied."

# ─────────────────────────────────────────────
#  10. Network — Nagle's Algorithm
# ─────────────────────────────────────────────
Write-Header "Network Latency: Disable Nagle's Algorithm"
Write-Detail "Nagle's Algorithm batches small packets — disabling it reduces TCP latency."

$tcpPath = "HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters\Interfaces"
Write-Action "Enumerating all TCP/IP network interfaces at:"
Write-Detail $tcpPath

$ifaces = Get-ChildItem -Path $tcpPath -ErrorAction SilentlyContinue
Write-Detail "Interfaces found: $($ifaces.Count)"

$ifIdx = 0
foreach ($iface in $ifaces) {
    $ifIdx++
    Write-Action "  [$ifIdx/$($ifaces.Count)] Interface GUID: $($iface.PSChildName)"
    try {
        Set-ItemProperty -Path $iface.PSPath -Name "TcpAckFrequency" -Value 1 -Type DWord -Force -ErrorAction Stop
        Write-Detail "         TcpAckFrequency = 1  (ACK every packet, no delay)"
    } catch {
        Write-Detail "         TcpAckFrequency — key not applicable for this adapter, skipped."
    }
    try {
        Set-ItemProperty -Path $iface.PSPath -Name "TCPNoDelay" -Value 1 -Type DWord -Force -ErrorAction Stop
        Write-Detail "         TCPNoDelay      = 1  (disable Nagle buffering)"
    } catch {
        Write-Detail "         TCPNoDelay      — key not applicable, skipped."
    }
}
Write-OK "Nagle's Algorithm disabled on all $ifIdx interface(s)."

# ─────────────────────────────────────────────
#  11. Temp File Cleanup
# ─────────────────────────────────────────────
Write-Header "Temporary File Cleanup"

$tempDirs = @(
    @{ Label = "User TEMP (%TEMP%)";              Path = $env:TEMP },
    @{ Label = "User TMP  (%TMP%)";               Path = $env:TMP  },
    @{ Label = "Windows Temp (C:\Windows\Temp)";  Path = "C:\Windows\Temp" }
)

foreach ($td in $tempDirs) {
    Write-Action "Scanning: $($td.Label)"
    Write-Detail "Path: $($td.Path)"
    if (Test-Path $td.Path) {
        $items  = Get-ChildItem -Path $td.Path -Recurse -Force -ErrorAction SilentlyContinue
        $total  = $items.Count
        $sizeMB = [math]::Round(
            ($items | Measure-Object -Property Length -Sum -ErrorAction SilentlyContinue).Sum / 1MB, 2)
        Write-Detail "Items found : $total"
        Write-Detail "Total size  : $sizeMB MB"
        Write-Action "Deleting items..."
        $deleted = 0; $locked = 0
        foreach ($item in $items) {
            try {
                Remove-Item -Path $item.FullName -Recurse -Force -ErrorAction Stop
                $deleted++
            } catch {
                $locked++
            }
        }
        Write-Detail "Deleted : $deleted  |  Locked/skipped: $locked"
        Write-OK "Cleaned '$($td.Label)' — freed ~$([math]::Round($sizeMB * ($deleted / [Math]::Max($total,1)), 2)) MB"
    } else {
        Write-Skip "Path not found: $($td.Path)"
    }
}

# ─────────────────────────────────────────────
#  12. Delivery Optimization
# ─────────────────────────────────────────────
Write-Header "Delivery Optimization (Windows Update P2P)"
Write-Action "Setting DODownloadMode = 0 (disable all P2P update sharing)..."
Write-Detail "Prevents Windows from uploading updates to other PCs on your network or the internet."
Set-RegVal "HKLM:\SOFTWARE\Policies\Microsoft\Windows\DeliveryOptimization" "DODownloadMode" 0
Write-OK "Delivery Optimization disabled."

# ─────────────────────────────────────────────
#  DONE
# ─────────────────────────────────────────────
Write-Summary
Read-Host "  Press ENTER to close"
