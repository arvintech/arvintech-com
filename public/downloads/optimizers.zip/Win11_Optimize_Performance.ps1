#Requires -RunAsAdministrator
<#
.SYNOPSIS
    Windows 11 Performance & Speed Optimizer
.DESCRIPTION
    Applies a comprehensive set of performance tweaks to Windows 11:
    visual effects, power plan, startup programs, services, and more.
.NOTES
    Run as Administrator. Creates a restore point before making changes.
#>

# ─────────────────────────────────────────────
#  Helpers
# ─────────────────────────────────────────────
function Write-Header {
    param([string]$Text)
    Write-Host "`n══════════════════════════════════════" -ForegroundColor Cyan
    Write-Host "  $Text" -ForegroundColor Cyan
    Write-Host "══════════════════════════════════════" -ForegroundColor Cyan
}

function Write-Step {
    param([string]$Text)
    Write-Host "  [>] $Text" -ForegroundColor Yellow
}

function Write-OK {
    param([string]$Text)
    Write-Host "  [✓] $Text" -ForegroundColor Green
}

function Write-Skip {
    param([string]$Text)
    Write-Host "  [-] $Text" -ForegroundColor DarkGray
}

# ─────────────────────────────────────────────
#  0. Restore Point
# ─────────────────────────────────────────────
Write-Header "Creating System Restore Point"
try {
    Enable-ComputerRestore -Drive "C:\" -ErrorAction SilentlyContinue
    Checkpoint-Computer -Description "Before Win11 Performance Optimization" -RestorePointType "MODIFY_SETTINGS" -ErrorAction Stop
    Write-OK "Restore point created."
} catch {
    Write-Skip "Could not create restore point (may already exist today): $_"
}

# ─────────────────────────────────────────────
#  1. Power Plan — High Performance
# ─────────────────────────────────────────────
Write-Header "Power Plan"
Write-Step "Activating High Performance power plan..."
$hp = powercfg -list | Select-String "High performance"
if ($hp) {
    $guid = ($hp -split '\s+')[3]
    powercfg -setactive $guid
    Write-OK "High Performance plan activated ($guid)."
} else {
    # Duplicate Balanced and name it High Performance
    $out = powercfg -duplicatescheme SCHEME_MIN
    $newGuid = ($out -split '\s+')[-1]
    powercfg -changename $newGuid "High Performance (Custom)"
    powercfg -setactive $newGuid
    Write-OK "Created & activated custom High Performance plan."
}

# ─────────────────────────────────────────────
#  2. Visual Effects — Performance Mode
# ─────────────────────────────────────────────
Write-Header "Visual Effects"
Write-Step "Setting Visual Effects to 'Adjust for best performance'..."
$regPath = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\VisualEffects"
Set-ItemProperty -Path $regPath -Name "VisualFXSetting" -Value 2 -Type DWord -Force
# Individual keys
$vfxPath = "HKCU:\Control Panel\Desktop"
Set-ItemProperty -Path $vfxPath -Name "DragFullWindows"          -Value "0"  -Force
Set-ItemProperty -Path $vfxPath -Name "MenuShowDelay"            -Value "0"  -Force
Set-ItemProperty -Path $vfxPath -Name "UserPreferencesMask"      -Value ([byte[]](0x90,0x12,0x01,0x80,0x10,0x00,0x00,0x00)) -Type Binary -Force
Set-ItemProperty -Path "HKCU:\Control Panel\Desktop\WindowMetrics" -Name "MinAnimate" -Value "0" -Force
Write-OK "Visual effects optimized."

# ─────────────────────────────────────────────
#  3. Disable Transparency & Animations
# ─────────────────────────────────────────────
Write-Header "Transparency & Animations"
Write-Step "Disabling transparency effects..."
Set-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize" `
    -Name "EnableTransparency" -Value 0 -Type DWord -Force
Write-Step "Disabling animation in taskbar..."
$advPath = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced"
Set-ItemProperty -Path $advPath -Name "TaskbarAnimations" -Value 0 -Type DWord -Force
Write-OK "Transparency and animations disabled."

# ─────────────────────────────────────────────
#  4. Disable Startup Delay
# ─────────────────────────────────────────────
Write-Header "Startup Delay"
Write-Step "Removing Explorer startup delay..."
$serializePath = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Serialize"
if (-not (Test-Path $serializePath)) { New-Item -Path $serializePath -Force | Out-Null }
Set-ItemProperty -Path $serializePath -Name "StartupDelayInMSec" -Value 0 -Type DWord -Force
Write-OK "Startup delay removed."

# ─────────────────────────────────────────────
#  5. Prefetch & Superfetch (SysMain)
# ─────────────────────────────────────────────
Write-Header "Prefetch / SysMain"
Write-Step "Enabling Prefetch and ReadyBoot (best for HDDs; neutral on SSDs)..."
$pfPath = "HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management\PrefetchParameters"
Set-ItemProperty -Path $pfPath -Name "EnablePrefetcher"   -Value 3 -Type DWord -Force
Set-ItemProperty -Path $pfPath -Name "EnableSuperfetch"   -Value 3 -Type DWord -Force
Write-OK "Prefetch settings applied."

# ─────────────────────────────────────────────
#  6. Disable Unnecessary Services
# ─────────────────────────────────────────────
Write-Header "Services"
$servicesToDisable = @(
    @{ Name = "DiagTrack";           Display = "Connected User Experiences & Telemetry" },
    @{ Name = "WSearch";             Display = "Windows Search (disable if not needed)" },
    @{ Name = "SysMain";             Display = "SysMain / Superfetch" },
    @{ Name = "MapsBroker";          Display = "Downloaded Maps Manager" },
    @{ Name = "XblAuthManager";      Display = "Xbox Live Auth Manager" },
    @{ Name = "XblGameSave";         Display = "Xbox Live Game Save" },
    @{ Name = "XboxNetApiSvc";       Display = "Xbox Live Networking Service" },
    @{ Name = "RetailDemo";          Display = "Retail Demo Service" }
)

foreach ($svc in $servicesToDisable) {
    $s = Get-Service -Name $svc.Name -ErrorAction SilentlyContinue
    if ($s) {
        Write-Step "Disabling: $($svc.Display)..."
        try {
            Stop-Service  -Name $svc.Name -Force -ErrorAction SilentlyContinue
            Set-Service   -Name $svc.Name -StartupType Disabled -ErrorAction Stop
            Write-OK "$($svc.Display) disabled."
        } catch {
            Write-Skip "Could not disable $($svc.Display): $_"
        }
    } else {
        Write-Skip "$($svc.Display) — not found, skipping."
    }
}

# ─────────────────────────────────────────────
#  7. Disable Background Apps
# ─────────────────────────────────────────────
Write-Header "Background Apps"
Write-Step "Restricting background app access globally..."
$bgPath = "HKCU:\Software\Microsoft\Windows\CurrentVersion\BackgroundAccessApplications"
Set-ItemProperty -Path $bgPath -Name "GlobalUserDisabled" -Value 1 -Type DWord -Force
Write-OK "Background apps restricted."

# ─────────────────────────────────────────────
#  8. Game Mode & Hardware-Accelerated GPU Scheduling
# ─────────────────────────────────────────────
Write-Header "Game Mode & GPU Scheduling"
Write-Step "Enabling Game Mode..."
$gamePath = "HKCU:\Software\Microsoft\GameBar"
Set-ItemProperty -Path $gamePath -Name "AllowAutoGameMode" -Value 1 -Type DWord -Force
Set-ItemProperty -Path $gamePath -Name "AutoGameModeEnabled" -Value 1 -Type DWord -Force
Write-OK "Game Mode enabled."

Write-Step "Enabling Hardware-Accelerated GPU Scheduling (HAGS)..."
$hagsPath = "HKLM:\SYSTEM\CurrentControlSet\Control\GraphicsDrivers"
Set-ItemProperty -Path $hagsPath -Name "HwSchMode" -Value 2 -Type DWord -Force
Write-OK "HAGS enabled (reboot required)."

# ─────────────────────────────────────────────
#  9. RAM & Paging Tweaks
# ─────────────────────────────────────────────
Write-Header "Memory / Paging"
Write-Step "Clearing page file at shutdown (security + performance)..."
$memPath = "HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management"
Set-ItemProperty -Path $memPath -Name "ClearPageFileAtShutdown" -Value 0 -Type DWord -Force
Write-Step "Keeping kernel in RAM (LargeSystemCache)..."
Set-ItemProperty -Path $memPath -Name "LargeSystemCache" -Value 0 -Type DWord -Force
Write-OK "Memory tweaks applied."

# ─────────────────────────────────────────────
#  10. Network — Nagle's Algorithm Off
# ─────────────────────────────────────────────
Write-Header "Network Tweaks"
Write-Step "Disabling Nagle's Algorithm for lower latency..."
$tcpPath = "HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters\Interfaces"
Get-ChildItem -Path $tcpPath | ForEach-Object {
    Set-ItemProperty -Path $_.PSPath -Name "TcpAckFrequency" -Value 1 -Type DWord -Force -ErrorAction SilentlyContinue
    Set-ItemProperty -Path $_.PSPath -Name "TCPNoDelay"      -Value 1 -Type DWord -Force -ErrorAction SilentlyContinue
}
Write-OK "Nagle's Algorithm disabled on all interfaces."

# ─────────────────────────────────────────────
#  11. Disk Cleanup (temp files)
# ─────────────────────────────────────────────
Write-Header "Temp File Cleanup"
Write-Step "Removing user temp files..."
$tempPaths = @($env:TEMP, $env:TMP, "C:\Windows\Temp")
foreach ($p in $tempPaths) {
    if (Test-Path $p) {
        Get-ChildItem -Path $p -Recurse -Force -ErrorAction SilentlyContinue |
            Remove-Item -Recurse -Force -ErrorAction SilentlyContinue
        Write-OK "Cleaned: $p"
    }
}

# ─────────────────────────────────────────────
#  12. Disable Delivery Optimization
# ─────────────────────────────────────────────
Write-Header "Delivery Optimization (Windows Update P2P)"
Write-Step "Disabling P2P update sharing..."
$doPath = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\DeliveryOptimization"
if (-not (Test-Path $doPath)) { New-Item -Path $doPath -Force | Out-Null }
Set-ItemProperty -Path $doPath -Name "DODownloadMode" -Value 0 -Type DWord -Force
Write-OK "Delivery Optimization disabled."

# ─────────────────────────────────────────────
#  Done
# ─────────────────────────────────────────────
Write-Header "All Done!"
Write-Host ""
Write-Host "  Windows 11 performance optimizations applied." -ForegroundColor White
Write-Host "  Please RESTART your computer to apply all changes." -ForegroundColor Magenta
Write-Host ""
