@echo off
:: =========================================================
::  Windows 11 Performance & Speed Optimizer
::  Run as Administrator
:: =========================================================
title Windows 11 Performance Optimizer
color 0B

net session >nul 2>&1
if %errorLevel% neq 0 (
    echo.
    echo  [!] This script must be run as Administrator.
    echo      Right-click the file and choose "Run as administrator".
    echo.
    pause
    exit /b 1
)

echo.
echo  =====================================================
echo    Windows 11 Performance ^& Speed Optimizer
echo  =====================================================
echo.
echo  This script will:
echo   - Set Power Plan to High Performance
echo   - Disable visual effects / transparency / animations
echo   - Disable unnecessary background services
echo   - Tweak memory and network settings
echo   - Clean temp files
echo.
echo  A System Restore Point will be created first.
echo.
pause

:: ─────────────────────────────────────────────
:: 0. Create Restore Point
:: ─────────────────────────────────────────────
echo.
echo  [*] Creating System Restore Point...
wmic.exe /Namespace:\\root\default Path SystemRestore Call CreateRestorePoint "Before Win11 Perf Optimization", 100, 7 >nul 2>&1
if %errorLevel%==0 (
    echo  [OK] Restore point created.
) else (
    echo  [-] Restore point skipped (may already exist today).
)

:: ─────────────────────────────────────────────
:: 1. Power Plan — High Performance
:: ─────────────────────────────────────────────
echo.
echo  =====================================================
echo   Power Plan
echo  =====================================================
echo  [*] Activating High Performance power plan...
powercfg -setactive 8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c >nul 2>&1
if %errorLevel%==0 (
    echo  [OK] High Performance plan activated.
) else (
    echo  [-] Built-in GUID not found, trying by name...
    for /f "tokens=4" %%G in ('powercfg -list ^| findstr /i "High performance"') do (
        powercfg -setactive %%G >nul 2>&1
        echo  [OK] Activated plan %%G
    )
)

:: ─────────────────────────────────────────────
:: 2. Visual Effects — Best Performance
:: ─────────────────────────────────────────────
echo.
echo  =====================================================
echo   Visual Effects
echo  =====================================================
echo  [*] Setting Visual Effects to "Adjust for best performance"...
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\VisualEffects" /v VisualFXSetting /t REG_DWORD /d 2 /f >nul
reg add "HKCU\Control Panel\Desktop" /v DragFullWindows /t REG_SZ /d 0 /f >nul
reg add "HKCU\Control Panel\Desktop" /v MenuShowDelay /t REG_SZ /d 0 /f >nul
reg add "HKCU\Control Panel\Desktop\WindowMetrics" /v MinAnimate /t REG_SZ /d 0 /f >nul
echo  [OK] Visual effects optimized.

:: ─────────────────────────────────────────────
:: 3. Disable Transparency & Taskbar Animation
:: ─────────────────────────────────────────────
echo.
echo  =====================================================
echo   Transparency ^& Animations
echo  =====================================================
echo  [*] Disabling transparency effects...
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize" /v EnableTransparency /t REG_DWORD /d 0 /f >nul
echo  [*] Disabling taskbar animations...
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v TaskbarAnimations /t REG_DWORD /d 0 /f >nul
echo  [OK] Transparency and animations disabled.

:: ─────────────────────────────────────────────
:: 4. Disable Startup Delay
:: ─────────────────────────────────────────────
echo.
echo  =====================================================
echo   Startup Delay
echo  =====================================================
echo  [*] Removing Explorer startup delay...
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Serialize" /v StartupDelayInMSec /t REG_DWORD /d 0 /f >nul
echo  [OK] Startup delay removed.

:: ─────────────────────────────────────────────
:: 5. Disable Unnecessary Services
:: ─────────────────────────────────────────────
echo.
echo  =====================================================
echo   Services
echo  =====================================================
echo  [*] Disabling unnecessary services...

sc stop DiagTrack >nul 2>&1
sc config DiagTrack start= disabled >nul 2>&1
echo  [OK] DiagTrack (Telemetry) disabled.

sc stop MapsBroker >nul 2>&1
sc config MapsBroker start= disabled >nul 2>&1
echo  [OK] Downloaded Maps Manager disabled.

sc stop XblAuthManager >nul 2>&1
sc config XblAuthManager start= disabled >nul 2>&1
echo  [OK] Xbox Live Auth Manager disabled.

sc stop XblGameSave >nul 2>&1
sc config XblGameSave start= disabled >nul 2>&1
echo  [OK] Xbox Live Game Save disabled.

sc stop XboxNetApiSvc >nul 2>&1
sc config XboxNetApiSvc start= disabled >nul 2>&1
echo  [OK] Xbox Live Networking disabled.

sc stop RetailDemo >nul 2>&1
sc config RetailDemo start= disabled >nul 2>&1
echo  [OK] Retail Demo Service disabled.

:: ─────────────────────────────────────────────
:: 6. Disable Background Apps
:: ─────────────────────────────────────────────
echo.
echo  =====================================================
echo   Background Apps
echo  =====================================================
echo  [*] Restricting background app access globally...
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\BackgroundAccessApplications" /v GlobalUserDisabled /t REG_DWORD /d 1 /f >nul
echo  [OK] Background apps restricted.

:: ─────────────────────────────────────────────
:: 7. Enable Game Mode
:: ─────────────────────────────────────────────
echo.
echo  =====================================================
echo   Game Mode
echo  =====================================================
echo  [*] Enabling Game Mode...
reg add "HKCU\Software\Microsoft\GameBar" /v AllowAutoGameMode /t REG_DWORD /d 1 /f >nul
reg add "HKCU\Software\Microsoft\GameBar" /v AutoGameModeEnabled /t REG_DWORD /d 1 /f >nul
echo  [OK] Game Mode enabled.

:: ─────────────────────────────────────────────
:: 8. Hardware-Accelerated GPU Scheduling (HAGS)
:: ─────────────────────────────────────────────
echo.
echo  =====================================================
echo   GPU Scheduling
echo  =====================================================
echo  [*] Enabling Hardware-Accelerated GPU Scheduling...
reg add "HKLM\SYSTEM\CurrentControlSet\Control\GraphicsDrivers" /v HwSchMode /t REG_DWORD /d 2 /f >nul
echo  [OK] HAGS enabled (reboot required).

:: ─────────────────────────────────────────────
:: 9. Disable Delivery Optimization
:: ─────────────────────────────────────────────
echo.
echo  =====================================================
echo   Delivery Optimization (Windows Update P2P)
echo  =====================================================
echo  [*] Disabling P2P Windows Update sharing...
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\DeliveryOptimization" /v DODownloadMode /t REG_DWORD /d 0 /f >nul
echo  [OK] Delivery Optimization disabled.

:: ─────────────────────────────────────────────
:: 10. Network — Disable Nagle's Algorithm
:: ─────────────────────────────────────────────
echo.
echo  =====================================================
echo   Network Tweaks
echo  =====================================================
echo  [*] Disabling Nagle's Algorithm (lower latency)...
for /f "tokens=*" %%k in ('reg query "HKLM\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters\Interfaces" /f "" /k 2^>nul ^| findstr /i "HKLM"') do (
    reg add "%%k" /v TcpAckFrequency /t REG_DWORD /d 1 /f >nul 2>&1
    reg add "%%k" /v TCPNoDelay      /t REG_DWORD /d 1 /f >nul 2>&1
)
echo  [OK] Nagle's Algorithm disabled.

:: ─────────────────────────────────────────────
:: 11. Clean Temp Files
:: ─────────────────────────────────────────────
echo.
echo  =====================================================
echo   Temp File Cleanup
echo  =====================================================
echo  [*] Cleaning user temp folder...
del /q /f /s "%TEMP%\*" >nul 2>&1
rd  /s /q "%TEMP%" >nul 2>&1
mkdir "%TEMP%" >nul 2>&1
echo  [OK] User temp cleaned.

echo  [*] Cleaning Windows temp folder...
del /q /f /s "C:\Windows\Temp\*" >nul 2>&1
echo  [OK] Windows temp cleaned.

:: ─────────────────────────────────────────────
:: Done
:: ─────────────────────────────────────────────
echo.
echo  =====================================================
echo   All Done!
echo  =====================================================
echo.
echo  Windows 11 performance optimizations applied.
echo.
echo  PLEASE RESTART YOUR COMPUTER to apply all changes.
echo.
pause
exit /b 0
