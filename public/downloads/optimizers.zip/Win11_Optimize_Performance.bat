@echo off
setlocal EnableDelayedExpansion
:: =========================================================
::  Windows 11 Performance & Speed Optimizer
::  VERBOSE EDITION  |  Run as Administrator
:: =========================================================
title Windows 11 Performance Optimizer [VERBOSE]
color 0B

:: Admin check
net session >nul 2>&1
if %errorLevel% neq 0 (
    echo.
    echo  [!!] This script must be run as Administrator.
    echo       Right-click the file and choose "Run as administrator".
    echo.
    pause & exit /b 1
)

set OK=0
set SKIP=0
set ERR=0

:: ─── Banner ───────────────────────────────────────────────
cls
echo.
echo  +======================================================+
echo  ^|    Windows 11 Performance ^& Speed Optimizer         ^|
echo  ^|    Verbose Edition  ^|  Running as Administrator      ^|
echo  +======================================================+
echo.
echo  Every registry key, service change, and file operation
echo  will be displayed as it happens.
echo.
echo  A System Restore Point will be created first.
echo.
pause

:: ─────────────────────────────────────────────────────────
:: STEP 0 — System Restore Point
:: ─────────────────────────────────────────────────────────
call :header "STEP 0: System Restore Point"

echo  [>>] Calling WMIC SystemRestore.CreateRestorePoint...
echo       Description : "Before Win11 Perf Optimization"
echo       RestorePointType: 100  (MODIFY_SETTINGS)
echo       EventType   : 7  (BEGIN_SYSTEM_CHANGE)
wmic.exe /Namespace:\\root\default Path SystemRestore Call CreateRestorePoint "Before Win11 Perf Optimization", 100, 7
if %errorLevel%==0 (
    call :ok "Restore point created."
) else (
    call :skip "Restore point skipped (may already exist today or VSS unavailable)."
)

:: ─────────────────────────────────────────────────────────
:: STEP 1 — Power Plan
:: ─────────────────────────────────────────────────────────
call :header "STEP 1: Power Plan -> High Performance"

echo  [>>] Listing all power plans:
powercfg -list
echo.
echo  [>>] Activating High Performance GUID: 8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c
powercfg -setactive 8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c
if %errorLevel%==0 (
    call :ok "High Performance plan activated (built-in GUID)."
) else (
    echo  [>>] Built-in GUID not found, searching by name...
    for /f "tokens=4" %%G in ('powercfg -list ^| findstr /i "High performance"') do (
        echo  [>>] Found GUID %%G — setting active...
        powercfg -setactive %%G
        call :ok "Activated plan %%G"
    )
)
echo  [>>] Active scheme after change:
powercfg -getactivescheme

:: ─────────────────────────────────────────────────────────
:: STEP 2 — Visual Effects
:: ─────────────────────────────────────────────────────────
call :header "STEP 2: Visual Effects -> Best Performance"

echo  [>>] Writing VisualFXSetting = 2 (Adjust for best performance)
echo       Path: HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\VisualEffects
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\VisualEffects" /v VisualFXSetting /t REG_DWORD /d 2 /f
call :regcheck "VisualFXSetting"

echo  [>>] Writing DragFullWindows = 0 (disable full window drag)
echo       Path: HKCU\Control Panel\Desktop
reg add "HKCU\Control Panel\Desktop" /v DragFullWindows /t REG_SZ /d 0 /f
call :regcheck "DragFullWindows"

echo  [>>] Writing MenuShowDelay = 0 ms (instant menus)
reg add "HKCU\Control Panel\Desktop" /v MenuShowDelay /t REG_SZ /d 0 /f
call :regcheck "MenuShowDelay"

echo  [>>] Writing MinAnimate = 0 (disable min/max animations)
echo       Path: HKCU\Control Panel\Desktop\WindowMetrics
reg add "HKCU\Control Panel\Desktop\WindowMetrics" /v MinAnimate /t REG_SZ /d 0 /f
call :regcheck "MinAnimate"

call :ok "All visual effect registry values written."

:: ─────────────────────────────────────────────────────────
:: STEP 3 — Transparency & Animations
:: ─────────────────────────────────────────────────────────
call :header "STEP 3: Transparency ^& Taskbar Animations"

echo  [>>] Writing EnableTransparency = 0 (disable Fluent/Acrylic)
echo       Path: HKCU\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize" /v EnableTransparency /t REG_DWORD /d 0 /f
call :regcheck "EnableTransparency"

echo  [>>] Writing TaskbarAnimations = 0 (disable taskbar button fade)
echo       Path: HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced" /v TaskbarAnimations /t REG_DWORD /d 0 /f
call :regcheck "TaskbarAnimations"

call :ok "Transparency and animations disabled."

:: ─────────────────────────────────────────────────────────
:: STEP 4 — Startup Delay
:: ─────────────────────────────────────────────────────────
call :header "STEP 4: Explorer Startup Delay"

echo  [>>] Writing StartupDelayInMSec = 0
echo       Path: HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Serialize
echo       Note: Windows default is 10000 ms (10 seconds). Setting to 0.
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Serialize" /v StartupDelayInMSec /t REG_DWORD /d 0 /f
call :regcheck "StartupDelayInMSec"
call :ok "Explorer startup delay removed (saved ~10s on login)."

:: ─────────────────────────────────────────────────────────
:: STEP 5 — Prefetch
:: ─────────────────────────────────────────────────────────
call :header "STEP 5: Prefetch / ReadyBoot"

echo  [>>] Reading current Prefetch values:
reg query "HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management\PrefetchParameters" /v EnablePrefetcher 2>nul
reg query "HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management\PrefetchParameters" /v EnableSuperfetch 2>nul
echo.

echo  [>>] Writing EnablePrefetcher = 3 (boot + app prefetch)
echo       Path: HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management\PrefetchParameters
reg add "HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management\PrefetchParameters" /v EnablePrefetcher /t REG_DWORD /d 3 /f
call :regcheck "EnablePrefetcher"

echo  [>>] Writing EnableSuperfetch = 3
reg add "HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management\PrefetchParameters" /v EnableSuperfetch /t REG_DWORD /d 3 /f
call :regcheck "EnableSuperfetch"

call :ok "Prefetch parameters set."

:: ─────────────────────────────────────────────────────────
:: STEP 6 — Services
:: ─────────────────────────────────────────────────────────
call :header "STEP 6: Disable Unnecessary Services"

call :disable_svc "DiagTrack"      "Connected User Experiences ^& Telemetry"
call :disable_svc "WSearch"        "Windows Search"
call :disable_svc "SysMain"        "SysMain (Superfetch)"
call :disable_svc "MapsBroker"     "Downloaded Maps Manager"
call :disable_svc "XblAuthManager" "Xbox Live Auth Manager"
call :disable_svc "XblGameSave"    "Xbox Live Game Save"
call :disable_svc "XboxNetApiSvc"  "Xbox Live Networking Service"
call :disable_svc "RetailDemo"     "Retail Demo Service"

:: ─────────────────────────────────────────────────────────
:: STEP 7 — Background Apps
:: ─────────────────────────────────────────────────────────
call :header "STEP 7: Background App Access"

echo  [>>] Writing GlobalUserDisabled = 1
echo       Path: HKCU\Software\Microsoft\Windows\CurrentVersion\BackgroundAccessApplications
echo       Effect: Blocks ALL Store apps from running in the background.
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\BackgroundAccessApplications" /v GlobalUserDisabled /t REG_DWORD /d 1 /f
call :regcheck "GlobalUserDisabled"
call :ok "Background apps restricted globally."

:: ─────────────────────────────────────────────────────────
:: STEP 8 — Game Mode & HAGS
:: ─────────────────────────────────────────────────────────
call :header "STEP 8: Game Mode ^& Hardware GPU Scheduling"

echo  [>>] Writing AllowAutoGameMode = 1
echo       Path: HKCU\Software\Microsoft\GameBar
reg add "HKCU\Software\Microsoft\GameBar" /v AllowAutoGameMode /t REG_DWORD /d 1 /f
call :regcheck "AllowAutoGameMode"

echo  [>>] Writing AutoGameModeEnabled = 1
reg add "HKCU\Software\Microsoft\GameBar" /v AutoGameModeEnabled /t REG_DWORD /d 1 /f
call :regcheck "AutoGameModeEnabled"
call :ok "Game Mode enabled."

echo  [>>] Writing HwSchMode = 2 (Hardware-Accelerated GPU Scheduling)
echo       Path: HKLM\SYSTEM\CurrentControlSet\Control\GraphicsDrivers
echo       Requires: DirectX 12 GPU + WDDM 2.7 driver. Takes effect after REBOOT.
reg add "HKLM\SYSTEM\CurrentControlSet\Control\GraphicsDrivers" /v HwSchMode /t REG_DWORD /d 2 /f
call :regcheck "HwSchMode"
call :ok "HAGS enabled. REBOOT REQUIRED."

:: ─────────────────────────────────────────────────────────
:: STEP 9 — Memory / Paging
:: ─────────────────────────────────────────────────────────
call :header "STEP 9: Memory ^& Page File Settings"

echo  [>>] Reading current memory management values:
reg query "HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management" /v ClearPageFileAtShutdown 2>nul
reg query "HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management" /v LargeSystemCache 2>nul
echo.

echo  [>>] Writing ClearPageFileAtShutdown = 0 (keep pagefile, faster shutdown)
echo       Path: HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management
reg add "HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management" /v ClearPageFileAtShutdown /t REG_DWORD /d 0 /f
call :regcheck "ClearPageFileAtShutdown"

echo  [>>] Writing LargeSystemCache = 0 (optimised for desktop apps, not file servers)
reg add "HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management" /v LargeSystemCache /t REG_DWORD /d 0 /f
call :regcheck "LargeSystemCache"

call :ok "Memory/paging settings applied."

:: ─────────────────────────────────────────────────────────
:: STEP 10 — Network
:: ─────────────────────────────────────────────────────────
call :header "STEP 10: Network Latency - Disable Nagle's Algorithm"

echo  [>>] Enumerating all TCP/IP interface subkeys...
echo       Path: HKLM\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters\Interfaces
echo.
set IF_IDX=0
for /f "tokens=*" %%K in ('reg query "HKLM\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters\Interfaces" 2^>nul') do (
    set /a IF_IDX+=1
    echo  [>>] Interface !IF_IDX!: %%K
    reg add "%%K" /v TcpAckFrequency /t REG_DWORD /d 1 /f >nul 2>&1
    if !errorLevel!==0 (
        echo       TcpAckFrequency = 1  [written]
    ) else (
        echo       TcpAckFrequency       [skipped - not applicable]
    )
    reg add "%%K" /v TCPNoDelay /t REG_DWORD /d 1 /f >nul 2>&1
    if !errorLevel!==0 (
        echo       TCPNoDelay      = 1  [written]
    ) else (
        echo       TCPNoDelay            [skipped - not applicable]
    )
)
call :ok "Nagle's Algorithm disabled on !IF_IDX! interface(s)."

:: ─────────────────────────────────────────────────────────
:: STEP 11 — Delivery Optimization
:: ─────────────────────────────────────────────────────────
call :header "STEP 11: Delivery Optimization (Windows Update P2P)"

echo  [>>] Reading current DODownloadMode:
reg query "HKLM\SOFTWARE\Policies\Microsoft\Windows\DeliveryOptimization" /v DODownloadMode 2>nul
if %errorLevel% neq 0 echo       (key not yet present — will be created)
echo.
echo  [>>] Writing DODownloadMode = 0  (disable all P2P update sharing)
echo       Path: HKLM\SOFTWARE\Policies\Microsoft\Windows\DeliveryOptimization
echo       Effect: Windows will no longer upload updates to other PCs.
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\DeliveryOptimization" /v DODownloadMode /t REG_DWORD /d 0 /f
call :regcheck "DODownloadMode"
call :ok "Delivery Optimization disabled."

:: ─────────────────────────────────────────────────────────
:: STEP 12 — Temp File Cleanup
:: ─────────────────────────────────────────────────────────
call :header "STEP 12: Temporary File Cleanup"

echo  [>>] Cleaning User TEMP folder: %TEMP%
echo  [>>] Deleting files...
del /q /f /s "%TEMP%\*" 2>nul
echo  [>>] Removing subdirectories...
for /d %%D in ("%TEMP%\*") do rd /s /q "%%D" 2>nul
call :ok "User TEMP cleaned."

echo  [>>] Cleaning Windows Temp folder: C:\Windows\Temp
del /q /f /s "C:\Windows\Temp\*" 2>nul
for /d %%D in ("C:\Windows\Temp\*") do rd /s /q "%%D" 2>nul
call :ok "Windows Temp cleaned."

:: ─────────────────────────────────────────────────────────
:: DONE — Summary
:: ─────────────────────────────────────────────────────────
echo.
echo  +======================================================+
echo  ^|                   RUN SUMMARY                        ^|
echo  +======================================================+
echo  ^|  OK Successful  : %OK%
echo  ^|  -- Skipped     : %SKIP%
echo  ^|  !! Errors      : %ERR%
echo  +------------------------------------------------------+
echo  ^|  ** PLEASE RESTART YOUR COMPUTER **                  ^|
echo  ^|     All changes take effect after reboot.            ^|
echo  +======================================================+
echo.
pause
exit /b 0

:: =============================================================
::  SUBROUTINES
:: =============================================================

:header
echo.
echo  +------------------------------------------------------
echo  ^|  %~1
echo  +------------------------------------------------------
goto :eof

:ok
set /a OK+=1
echo  [OK] %~1
goto :eof

:skip
set /a SKIP+=1
echo  [--] %~1
goto :eof

:err
set /a ERR+=1
echo  [!!] %~1
goto :eof

:regcheck
if %errorLevel%==0 (
    echo       [written successfully]
) else (
    echo       [FAILED to write]
    set /a ERR+=1
)
goto :eof

:disable_svc
:: %1 = service name,  %2 = display name
echo  [>>] Service: %~2  [%~1]
sc query "%~1" >nul 2>&1
if %errorLevel% neq 0 (
    echo       Status    : NOT FOUND on this system
    call :skip "%~2 [%~1] not found — skipped."
    goto :eof
)
echo  [>>] Querying current state:
sc query "%~1" | findstr /i "STATE\|TYPE"
echo  [>>] Querying startup type:
sc qc "%~1" | findstr /i "START_TYPE"
echo  [>>] Stopping service...
sc stop "%~1" >nul 2>&1
ping -n 2 127.0.0.1 >nul
echo  [>>] Setting StartupType = DISABLED...
sc config "%~1" start= disabled
if %errorLevel%==0 (
    call :ok "%~2 — DISABLED."
) else (
    call :err "Could not disable %~2."
)
goto :eof
